import os
import numpy as np
import cv2
import matplotlib.pyplot as plt

os.chdir(os.path.dirname(os.path.abspath(__file__)))

img_orig = cv2.imread('lena.jpg', cv2.IMREAD_GRAYSCALE)
    
img_sobelX = cv2.Sobel(img_orig, cv2.CV_64F, 1, 0, ksize=3)
img_sobelY = cv2.Sobel(img_orig, cv2.CV_64F, 0, 1, ksize=3)

img_sobelX = cv2.convertScaleAbs(img_sobelX)
img_sobelY = cv2.convertScaleAbs(img_sobelY)
img_sobel = cv2.addWeighted(img_sobelX, 1, img_sobelY, 1, 0)

res_gaussian_blur = cv2.GaussianBlur(img_sobel, (3,3), 0)

# Display results
titles = ['Original', 'Gaussian', 'Derivative', 'Sobel X']
images = [img_orig, res_gaussian_blur, img_sobelX, img_sobelX]

for i in range(4):
    plt.subplot(2, 2, i+1)
    plt.imshow(images[i], cmap='gray')
    plt.title(titles[i])
    plt.xticks([]), plt.yticks([])
plt.show()
