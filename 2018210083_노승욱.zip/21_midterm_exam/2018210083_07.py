import os
import numpy as np
import cv2
import matplotlib.pyplot as plt

os.chdir(os.path.dirname(os.path.abspath(__file__)))

winname = 'Canny Edge Detection'
cv2.namedWindow(winname)
cv2.createTrackbar('minVal', winname, 2000, 5000, do_nothing)
cv2.createTrackbar('maxVal', winname, 4000, 5000, do_nothing)

img = cv2.imread('lena.jpg', cv2.IMREAD_GRAYSCALE)

edge1 = cv2.Canny(img, 1690, 3056)


cv2.imshow('original', img)
cv2.imshow('Canny Edge1', edge1)



img_vis = frame.copy()
img_vis = np.uint8(img_vis/2.)
img_vis[img_edge != 0] = (0, 255, 0)
cv.imshow(winname, img_vis)
ch = cv.waitKey(0)
cv2.destroyAllWindows()